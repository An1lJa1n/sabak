exports.firebaseRef = function(){
	var Firebase = require("firebase");
	return new Firebase("https://sabak.firebaseio.com/");	
}


